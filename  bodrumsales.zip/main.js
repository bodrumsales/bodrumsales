<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hoş Geldiniz</title>
  <style>
    body {
      font-family: sans-serif;
      text-align: center;
      padding: 100px;
      background-color: #fafafa;
    }
    a {
      background-color: #e1306c;
      color: white;
      padding: 15px 25px;
      text-decoration: none;
      border-radius: 8px;
      font-size: 18px;
    }
    a:hover {
      background-color: #c52c5d;
    }
  </style>
</head>
<body>
  <h1>Merhaba!</h1>
  <p>Web sitemiz şu an yapım aşamasında.</p>
  <p>Bizi Instagram'da takip edin:</p>
  <a href="https://www.instagram.com/bodrumsales/" target="_blank">Instagram'a Git</a>
</body>
</html><!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hoş Geldiniz</title>
  <style>
    body {
      font-family: sans-serif;
      text-align: center;
      padding: 100px;
      background-color: #fafafa;
    }
    a {
      background-color: #e1306c;
      color: white;
      padding: 15px 25px;
      text-decoration: none;
      border-radius: 8px;
      font-size: 18px;
    }
    a:hover {
      background-color: #c52c5d;
    }
  </style>
</head>
<body>
  <h1>Merhaba!</h1>
  <p>Web sitemiz şu an yapım aşamasında.</p>
  <p>Bizi Instagram'da takip edin:</p>
  <a href="https://www.instagram.com/bodrumsales/" target="_blank">Instagram'a Git</a>
</body>
</html>